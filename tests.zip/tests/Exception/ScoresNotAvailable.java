
public class ScoresNotAvailableException extends Exception{
	public ScoresNotAvailableException() {
	
		super();
	}
}
