
public class FileTooBigException extends Exception{
	 FileTooBigException(){
		 super();
		 
	 }

}
