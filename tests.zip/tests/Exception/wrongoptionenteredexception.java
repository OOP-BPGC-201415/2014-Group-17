
public class wrongoptionenteredexception extends Exception {
public wrongoptionenteredexception(){
	super();
}

}
