
public class EventNotOccurredException extends Exception{
	EventNotOccurredException(){
		super();
		
	}
}
