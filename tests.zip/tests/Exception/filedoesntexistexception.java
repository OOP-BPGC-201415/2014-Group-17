
public class filedoesntexistexception extends Exception {

}
